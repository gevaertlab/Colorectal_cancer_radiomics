fidFig = fopen('errorsIterationFig.err','wt');
errorIterationRecoderFig = [];
for i = 1:2
% for Chao's Mac OS.
    dicomPath = strcat('/Users/messi/Documents/private_research/Stanford_BMI/TCIA_TCGA/Lung1_dataset/DOI/LUNG1-', num2str(i,'%03d'));
% for Joe's Windows OS.
   % dicomPath = strcat('E:\chao20170716\TCIA_TCGA\Lung1_dataset\DOI\LUNG1-', num2str(i,'%03d'));

S = subdir(dicomPath); % from 'mvallieres-chao_revised' folder.if isempty(sData{4})
if sum([S(~ismember({S.name},{'.','..'})).isdir]) < 3  
    continue
else
    try
    [sData] = readDICOMdir(dicomPath,1); % from 'mvallieres-chao_revised' folder.
    
    volume = sData{2}.scan.volume;
    mask = sData{2}.scan.contour.mask;
    volume_temp = volume + 32770; % avoid the Os being deleted after multiply mask.
    ROI_ori=volume_temp.*mask;
    ROI_ori(ROI_ori == 0) = NaN;
    ROI_ori = ROI_ori-32770; % original ROI before resampling.
    
    [x,y,z] = find3d(~isnan(ROI_ori)); % find3d x,y,z coordinators, the function is adapted from
    % 'computeBoundingBox.m' of 'mvallieres/radiomics'
    ROI_real = ROI_ori(~isnan(ROI_ori)); % extract non-NaN elements of ROI_ori.
    pixelList = [find(~isnan(ROI_ori)), x',y',z', ROI_real(:)];
    pixel_idx = pixelList(~isnan(pixelList(:,5)),1);
    pixelList_4Kmeans = pixelList(~isnan(pixelList(:,5)),2:5);

    [cluster,C] = kmeans(pixelList_4Kmeans, 2); % returns an n-by-1 vector (idx) containing cluster indices of each observation

    pixelListNew = [pixel_idx, pixelList_4Kmeans, cluster];
    
    % rename the clusters: high,short for 'high intensity subvolume', means higher average intensity across the
    % cluster; low,short for 'low intensity subvolume', means lower average intensity across the
    % cluster;
    % uniformize cluster values: 1, 'low'; 2, 'high'.
    if C(1,4) > C(2,4)
        pixelListNew(pixelListNew(:,6)==1,6)=3;
        pixelListNew(pixelListNew(:,6)==2,6)=1;
        pixelListNew(pixelListNew(:,6)==3,6)=2;
    end
    
    % 3-D image of gross tumor volume(GTV) and tumor subvolume.
    colors = lines(2);
% What are those unique clusters? 
uniqueClusters = unique(cluster); 

    figure, hold on
    for k = 1:length(uniqueClusters)
       % Get indices of this particular unique cluster:
       ind = cluster == uniqueClusters(k);
       X = pixelListNew(:,2); Y = pixelListNew(:,3); Z = pixelListNew(:,4);
       % Plot only this group: 
      plot3(X(ind),Y(ind),Z(ind),'.','color',colors(k,:),'markersize',20); 
    end 
       legend('Low intensity subvolume', 'High intensity subvolume')
    hold off
    view(3), axis vis3d, box on, rotate3d on, grid on
    xlabel('Row'), ylabel('Column'), zlabel('Slice')
    filename = sprintf('Fig %d.%d 3-D visualization of gross tumor volume and tumor subvolumes.fig', i, 1);
    saveas(gcf, filename);

    % create 2-D image for individual slices
    %figure, hold on
    %pixelListNew1 = pixelListNew(pixelListNew(:,4)==70,:);
    %scatter(pixelListNew1(:, 2), pixelListNew1(:,3),100,clr(pixelListNew1(:,6),:),'filled', 'Marker','s')
    %hold off
    %xlabel('Row'), ylabel('Column')
    %title '5th slice of patient 001?s tumor'

    %figure, hold on
    %pixelListNew1 = pixelListNew(pixelListNew(:,4)==83,:);
    %scatter(pixelListNew1(:, 2), pixelListNew1(:,3),100,clr(pixelListNew1(:,6),:),'filled', 'Marker','s')
    %hold off
    %xlabel('Row'), ylabel('Column')
    %title '18th slice of patient 001?s tumor'
    
    int1=pixelListNew(pixelListNew(:,6)==1,5);
    int2=pixelListNew(pixelListNew(:,6)==2,5);

    min(int1)
    min(int2)

    figure,hold on
    subplot(2,1,1)
    hist(int1,100)
    title('Low Intensity Subvolume')

    subplot(2,1,2)
    hist(int2,100)
    title('High Intensity Subvolume')
    hold off
    filename = sprintf('Fig %d.%d Intensity distribution of tumor subvolumes.jpg', i, 2);
    saveas(gcf, filename);
    
    catch MEfig
        errorIterationRecoderFig = [errorIterationRecoderFig;i];
        fprintf(fidFig,'\n********************\n****Iteration %d*****\n********************\nMessage:"%s".\t\n',i, getReport(MEfig));
    end
end
end

fclose(fidFig);
csvwrite('errorIterationRecoderFig.csv', errorIterationRecoderFig);