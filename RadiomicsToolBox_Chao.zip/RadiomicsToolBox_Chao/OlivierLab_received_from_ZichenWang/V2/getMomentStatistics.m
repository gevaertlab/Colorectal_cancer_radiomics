function [HistFeas] = getMomentStatistics( centralcount, N)

%
% bin features (check 2d pipeline)
% check olivier code for histograms
% quantatile features (look at histogram regional variations)

% mask = ~isnan(ROIonly); % Find mask covering the ROI
% numberVoxel = sum(mask(:));
% im_max=max(max(max(ROIonly)));
% im_min=min(min(min(ROIonly)));
% im_ave=sum(ROIonly(mask))/numberVoxel;
% im_std=std(ROIonly(mask));
% im_var=var(ROIonly(mask));
% im_range = range(ROIonly(mask));
% im_median = median(ROIonly(mask));
% %im_iqr = iqr(ROIonly(mask));
% im_sum = sum(ROIonly(mask));
% 
% 



histo=centralcount;
% COMPUTATION OF HistFeas

% 1. Variance
HistFeas.Variance = var(histo);

% 2. Skewness
HistFeas.Skewness = skewness(histo);

% 3. Kurtosis
HistFeas.Kurtosis = kurtosis(histo);

% 4. Entropy
HistFeas.Entropy=entropy(histo);

% 5. Uniformity
HistFeas.Uniformity=sum(histo.*histo);

% 6 Mean 
HistFeas.MeanHist = mean(histo);

% 7 Median
HistFeas.MedianHist = median(histo);

%8 Range
HistFeas.RangeValue = range(histo);%difference between large and min of histogram.

%9 Inter range
HistFeas.InterRangeValue = iqr(histo);

%10 Median deviation
HistFeas.MedianDeviation = mad(histo);

%11 Har mean 
HistFeas.HarMean = harmmean(histo);

%11 Geo mean 
HistFeas.GeoMean = geomean(abs(histo));

%12 Trimmed mean, excluding 25%.
HistFeas.GeoMean = trimmean(histo,25);

%13 Central moment 
HistFeas.Moment = moment(histo,2);

%14-17 Quantitle values 
HistFeas.Quantile1 = quantile(histo,[0.025]);
HistFeas.Quantile2 = quantile(histo,[0.25]);
HistFeas.Quantile3 = quantile(histo,[0.75]);
HistFeas.Quantile4 = quantile(histo,[0.975]);

%17-20 Quantitle values 
HistFeas.Percentile1 = prctile(histo,25);
HistFeas.Percentile2 = prctile(histo,50);
HistFeas.Percentile3 = prctile(histo,75);
HistFeas.Percentile4 = prctile(histo,95);


end