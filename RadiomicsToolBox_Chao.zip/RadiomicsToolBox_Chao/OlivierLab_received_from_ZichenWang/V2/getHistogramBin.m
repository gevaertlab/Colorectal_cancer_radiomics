%% 50-bin histogram itself
function [histo] = getHistogramBin( ROIonly, N)

% PRELIMINARY
Nbins=N;
vectorValid = ROIonly(~isnan(ROIonly));
histo = hist(vectorValid,Nbins);
histo = histo./(sum(histo(:)));
vectNg = 1:Nbins;
u = histo*vectNg';

end
