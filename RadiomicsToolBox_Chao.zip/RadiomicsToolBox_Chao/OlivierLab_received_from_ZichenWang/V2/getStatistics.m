function [im_max,im_min,im_ave,im_std,im_var,im_range,im_median,im_sum] = getStatistics( ROIonly )
%GETMAX Summary of this function goes here
%   Detailed explanation goes here
mask = ~isnan(ROIonly); % Find mask covering the ROI
numberVoxel = sum(mask(:));
im_max=max(max(max(ROIonly)));
im_min=min(min(min(ROIonly)));
im_ave=sum(ROIonly(mask))/numberVoxel;
im_std=std(ROIonly(mask));
im_var=var(ROIonly(mask));
im_range = range(ROIonly(mask));
im_median = median(ROIonly(mask));
%im_iqr = iqr(ROIonly(mask));
im_sum = sum(ROIonly(mask));

end