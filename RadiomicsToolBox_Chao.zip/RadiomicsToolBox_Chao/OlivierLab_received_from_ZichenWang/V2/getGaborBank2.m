function [ textures ] = getGaborBank2( gaborImg,maskBox,quantAlgo,Ng )

[i,k]=size(gaborImg);

% 4 Frequencies and 8 Directions
for i=1:1:4
    for k =1:4
    ROIbox=gaborImg{i,k};
    [ROIonly,~,ROIbox,maskBox] =preareoneGaborVolume( ROIbox,maskBox,'Global',quantAlgo,Ng );
    % Global feature
    [Global_text] = getGlobalTextures(ROIonly,100);
    Global_text_names=fieldnames(Global_text);
    for j=1:1:length(Global_text_names)
        datanum=getfield(Global_text,Global_text_names{j});
        featurename=['F' num2str(i) num2str(k) num2str(j) 'Global' Global_text_names{j}];
        textures.(featurename)=datanum;
    end
    % GLCM feature
    [ROIonly,levels] = preareoneGaborVolume( ROIbox,maskBox,'Matrix',quantAlgo,Ng );
    [GLCM] = getGLCM(ROIonly,levels); 
    [GLCM_text] = getGLCMtextures(GLCM);
    GLCM_text_names=fieldnames(GLCM_text);
    for j=1:1:length(GLCM_text_names)
        datanum=getfield(GLCM_text,GLCM_text_names{j});
        featurename=['F' num2str(i) num2str(k) num2str(j) 'GLCM' GLCM_text_names{j}];
        textures.(featurename)=datanum;
    end
    % GLRLM feature
    [GLRLM] = getGLRLM(ROIonly,levels); 
    [GLRLM_text] = getGLRLMtextures(GLRLM);
    GLRLM_text_names=fieldnames(GLRLM_text);
    for j=1:1:length(GLRLM_text_names)
        datanum=getfield(GLRLM_text,GLRLM_text_names{j});
        featurename=['F' num2str(i) num2str(k) num2str(j) 'GLRLM' GLRLM_text_names{j}];
        textures.(featurename)=datanum;
    end
    % GLSZM feature
    [GLSZM] = getGLSZM(ROIonly,levels); 
    [GLSZM_text] = getGLSZMtextures(GLSZM);
    GLSZM_text_names=fieldnames(GLSZM_text);
    for j=1:1:length(GLSZM_text_names)
        datanum=getfield(GLSZM_text,GLSZM_text_names{j});
        featurename=['F' num2str(i) num2str(k) num2str(j) 'GLSZM' GLSZM_text_names{j}];
        textures.(featurename)=datanum;
    end
    % NGTDM feature
    [NGTDM,countValid] = getNGTDM(ROIonly,levels);
    [NGTDM_text] = getNGTDMtextures(NGTDM,countValid);
    NGTDM_text_names=fieldnames(NGTDM_text);
    for j=1:1:length(NGTDM_text_names)
        datanum=getfield(NGTDM_text,NGTDM_text_names{j});
        featurename=['F' num2str(i) num2str(k) num2str(j) 'NGTDM' NGTDM_text_names{j}];
        textures.(featurename)=datanum;
    end
    end
end

%% 


    


end

