function [HistFeas] = getGlobalHistogram( ROIonly, N)

%
% bin features (check 2d pipeline)
% check olivier code for histograms
% quantatile features (look at histogram regional variations)


% mask = ~isnan(ROIonly); % Find mask covering the ROI
% numberVoxel = sum(mask(:));
% im_max=max(max(max(ROIonly)));
% im_min=min(min(min(ROIonly)));
% im_ave=sum(ROIonly(mask))/numberVoxel;
% im_std=std(ROIonly(mask));
% im_var=var(ROIonly(mask));
% im_range = range(ROIonly(mask));
% im_median = median(ROIonly(mask));
% %im_iqr = iqr(ROIonly(mask));
% im_sum = sum(ROIonly(mask));
% 
% 

% PRELIMINARY
Nbins=N;
vectorValid = ROIonly(~isnan(ROIonly));
histo = hist(vectorValid,Nbins);
histo = histo./(sum(histo(:)));
vectNg = 1:Nbins;
u = histo*vectNg';


% COMPUTATION OF HistFeas
% 1. Variance
variance = 0;
for i=1:Nbins
    variance = variance+histo(i)*(i-u)^2;
end
sigma = sqrt(variance);
HistFeas.Variance = variance;

% 2. Skewness
skewness = 0;
for i = 1:Nbins
    skewness = skewness+histo(i)*(i-u)^3;
end
skewness = skewness/sigma^3;
HistFeas.Skewness = skewness;

% 3. Kurtosis
kurtosis = 0;
for i = 1:Nbins
    kurtosis = kurtosis+histo(i)*(i-u)^4;
end
kurtosis = (kurtosis/sigma^4) - 3;
HistFeas.Kurtosis = kurtosis;

% 4. Entropy
%HistFeas.Entropy=-sum(histo.*log2(histo+realmin));
HistFeas.Entropy=entropy(histo);

% 5. Uniformity
HistFeas.Uniformity=sum(histo.*histo);

% 6 Mean 
HistFeas.MeanHist = mean(histo);

% 7 Median
HistFeas.MedianHist = median(histo);

%8 Range
HistFeas.RangeValue = range(histo);%difference between large and min of histogram.

%9 Inter range
HistFeas.InterRangeValue = iqr(histo);

%10 Median deviation
HistFeas.MedianDeviation = mad(histo);

%11 Har mean 
HistFeas.HarMean = harmmean(histo);

%11 Geo mean 
HistFeas.GeoMean = geomean(histo);

%12 Trimmed mean, excluding 25%.
HistFeas.GeoMean = trimmean(histo,25);

%13 Central moment 
HistFeas.Moment = moment(histo,2);

%14-17 Quantitle values 
HistFeas.Quantile1 = quantile(histo,[0.025]);
HistFeas.Quantile2 = quantile(histo,[0.25]);
HistFeas.Quantile3 = quantile(histo,[0.75]);
HistFeas.Quantile4 = quantile(histo,[0.975]);

%18-21 Quantitle values 
HistFeas.Percentile1 = prctile(histo,25);
HistFeas.Percentile2 = prctile(histo,50);
HistFeas.Percentile3 = prctile(histo,75);
HistFeas.Percentile4 = prctile(histo,95);


end