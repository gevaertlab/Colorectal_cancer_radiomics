function [ textures ] = getGaborBank_v2( gaborImg,maskBox,quantAlgo,Ng )

fri_num=length(gaborImg.Freimg);
dir_num=length(gaborImg.Dirimg);

fri_num=8;
dir_num=8;

% 4 Frequencies and 8 Directions
for i=1:1:fri_num
    ROIbox=gaborImg.Freimg{1,i};
    [ROIonly,~,ROIbox,maskBox] =preareoneGaborVolume( ROIbox,maskBox,'Global',quantAlgo,Ng );
    % Global feature
    [Global_text] = getGlobalTextures(ROIonly,100);
    Global_text_names=fieldnames(Global_text);
    for j=1:1:length(Global_text_names)
        datanum=getfield(Global_text,Global_text_names{j});
        featurename=['Frequency' num2str(i) '_Global_' Global_text_names{j}];
        textures.(featurename)=datanum;
    end
    
    % GLCM feature
    [ROIonly,levels] = preareoneGaborVolume( ROIbox,maskBox,'Matrix',quantAlgo,Ng );
    [GLCM] = getGLCM(ROIonly,levels); 
    [GLCM_text] = getGLCMtextures(GLCM);
    GLCM_text_names=fieldnames(GLCM_text);
    for j=1:1:length(GLCM_text_names)
        datanum=getfield(GLCM_text,GLCM_text_names{j});
        featurename=['Frequency' num2str(i) '_GLCM_' GLCM_text_names{j}];
        textures.(featurename)=datanum;
    end
    % GLRLM feature
    [GLRLM] = getGLRLM(ROIonly,levels); 
    [GLRLM_text] = getGLRLMtextures(GLRLM);
    GLRLM_text_names=fieldnames(GLRLM_text);
    for j=1:1:length(GLRLM_text_names)
        datanum=getfield(GLRLM_text,GLRLM_text_names{j});
        featurename=['Frequency' num2str(i) '_GLRLM_' GLRLM_text_names{j}];
        textures.(featurename)=datanum;
    end
    % GLSZM feature
    [GLSZM] = getGLSZM(ROIonly,levels); 
    [GLSZM_text] = getGLSZMtextures(GLSZM);
    GLSZM_text_names=fieldnames(GLSZM_text);
    for j=1:1:length(GLSZM_text_names)
        datanum=getfield(GLSZM_text,GLSZM_text_names{j});
        featurename=['Frequency' num2str(i) '_GLSZM_' GLSZM_text_names{j}];
        textures.(featurename)=datanum;
    end
    % NGTDM feature
    [NGTDM,countValid] = getNGTDM(ROIonly,levels);
    [NGTDM_text] = getNGTDMtextures(NGTDM,countValid);
    NGTDM_text_names=fieldnames(NGTDM_text);
    for j=1:1:length(NGTDM_text_names)
        datanum=getfield(NGTDM_text,NGTDM_text_names{j});
        featurename=['Frequancy' num2str(i) '_NGTDM_' NGTDM_text_names{j}];
        textures.(featurename)=datanum;
    end
end

%% 

for i=1:1:dir_num
    ROIbox=gaborImg.Dirimg{1,i};
    [ROIonly,~,ROIbox,maskBox] =preareoneGaborVolume( ROIbox,maskBox,'Global',quantAlgo,Ng );
    % Global feature
    [Global_text] = getGlobalTextures(ROIonly,100);
    Global_text_names=fieldnames(Global_text);
    for j=1:1:length(Global_text_names)
        datanum=getfield(Global_text,Global_text_names{j});
        featurename=['Direction' num2str(i) '_Global_' Global_text_names{j}];
        textures.(featurename)=datanum;
    end
    % GLCM feature
    [ROIonly,levels] = preareoneGaborVolume( ROIbox,maskBox,'Matrix',quantAlgo,Ng );
    [GLCM] = getGLCM(ROIonly,levels); 
    [GLCM_text] = getGLCMtextures(GLCM);
    GLCM_text_names=fieldnames(GLCM_text);
    for j=1:1:length(GLCM_text_names)
        datanum=getfield(GLCM_text,GLCM_text_names{j});
        featurename=['Direction' num2str(i) '_GLCM_' GLCM_text_names{j}];
        textures.(featurename)=datanum;
    end
    % GLRLM feature
    [GLRLM] = getGLRLM(ROIonly,levels); 
    [GLRLM_text] = getGLRLMtextures(GLRLM);
    GLRLM_text_names=fieldnames(GLRLM_text);
    for j=1:1:length(GLRLM_text_names)
        datanum=getfield(GLRLM_text,GLRLM_text_names{j});
        featurename=['Direction' num2str(i) '_GLRLM_' GLRLM_text_names{j}];
        textures.(featurename)=datanum;
    end
    % GLSZM feature
    [GLSZM] = getGLSZM(ROIonly,levels); 
    [GLSZM_text] = getGLSZMtextures(GLSZM);
    GLSZM_text_names=fieldnames(GLSZM_text);
    for j=1:1:length(GLSZM_text_names)
        datanum=getfield(GLSZM_text,GLSZM_text_names{j});
        featurename=['Direction' num2str(i) '_GLSZM_' GLSZM_text_names{j}];
        textures.(featurename)=datanum;
    end
    % NGTDM feature
    [NGTDM,countValid] = getNGTDM(ROIonly,levels);
    [NGTDM_text] = getNGTDMtextures(NGTDM,countValid);
    NGTDM_text_names=fieldnames(NGTDM_text);
    for j=1:1:length(NGTDM_text_names)
        datanum=getfield(NGTDM_text,NGTDM_text_names{j});
        featurename=['Direction' num2str(i) '_NGTDM_' NGTDM_text_names{j}];
        textures.(featurename)=datanum;
    end
end
    
    


end

