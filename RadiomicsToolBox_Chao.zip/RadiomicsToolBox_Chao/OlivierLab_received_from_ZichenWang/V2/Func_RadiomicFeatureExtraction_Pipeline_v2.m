function [features,textures,featureList] = Func_RadiomicFeatureExtraction_Pipeline_v2(DataVolume,MaskVolume,Para)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

%% set up

features=[];
experiment = 0;
startPos=[]; % starting position of a feature vector.
res = []; % current feature vector, a temp variable.
featureList = {};

textures.List = '';
textures.Parameters.R = Para.R_mat;
textures.Parameters.Scale = Para.scale_cell;
textures.Parameters.Algo = Para.algo_cell;
textures.Parameters.Ng = Para.Ng_mat;

volume = DataVolume;
mask = MaskVolume;

algo_cell = Para.algo_cell;
R_mat = Para.R_mat;
scale_cell = Para.scale_cell;
Ng_mat = Para.Ng_mat;
pixelW = Para.pixel_space; 
sliceS = Para.slice_space; 

try
scanType = Para.type;
catch
    %scanType =sData{2}.scan.type;
end
clear sData{2};

experiment = experiment + 1;
strExperiment = ['Experiment',num2str(experiment)];
nameExperiment = ['R=',num2str(R_mat,'%.2f'),', Scale=',num2str(scale_cell{1}),', Quant.Algo=',algo_cell,', Ng=',num2str(Ng_mat)];
textures.List.(strExperiment) = nameExperiment;


%ROIonly is tumor data, ROIbox is all data, maskBox is tumor mask
[ROIonly,~,ROIbox,maskBox] = prepareVolume(volume,mask,scanType,pixelW,sliceS,R_mat,scale_cell{1},'Global');%volume normalization


%% Feature extraction starts below
%% statistical features n = 11

%[ im_max,im_min,im_ave,im_std ] = getMaxMinAveStd( ROIonly );
[im_max,im_min,im_ave,im_std,im_var,im_range,im_median,im_sum] = getStatistics( ROIonly );
StatisticalFea.Max=im_max;
StatisticalFea.Min=im_min;
StatisticalFea.Ave=im_ave;
StatisticalFea.Std=im_std;
StatisticalFea.Var=im_var;
StatisticalFea.Range=im_range;
StatisticalFea.Median=im_median;
StatisticalFea.Sum=im_sum;
features=[StatisticalFea.Max,StatisticalFea.Min,StatisticalFea.Ave,StatisticalFea.Std,StatisticalFea.Var,StatisticalFea.Range,StatisticalFea.Median,StatisticalFea.Sum];
if length(size(ROIonly)) ==2
StatisticalFea.Eccentricity=0;
StatisticalFea.Solidity=1;
StatisticalFea.Volume=getVolume(ROIonly,pixelW,sliceS);
else
StatisticalFea.Eccentricity=getEccentricity(ROIonly,pixelW,sliceS);
StatisticalFea.Solidity=getSolidity(ROIonly,pixelW,sliceS);
StatisticalFea.Volume=getVolume(ROIonly,pixelW,sliceS);
end



% StatisticalFea.SizeROI=getSize(ROIonly,pixelW,sliceS);
features=[features,StatisticalFea.Eccentricity,StatisticalFea.Solidity,StatisticalFea.Volume];

fv_name = {
    'Lesion-Max', 'Lesion-Min', 'Lesion-Ave', ...
    'Lesion-Std','Lesion-Var','Lesion-Range','Lesion-Median',...
    'Lesion-Sum','Lesion-Eccenticity', 'Lesion-Solidity', ...
    'Lesion-Volume'};
res = [res;features'];
startPos = [startPos; length(res)+1];
[~,~,featureList] = AppendFeatureList(features, fv_name, res, startPos, featureList);
fprintf('Done extracting 11 global statistical features.\n');



%% Central moment and Hu moment features
% A = ROIonly;
% A(isnan(A))=0;
% HuMoment=[];
% for i = 1 : size(A,3)
% cen_mmt(i) = Centr_Moment(double(A(:,:,i)),double(maskBox(:,:,i)),1,1);
% eta = SI_Moment(A(:,:,i), maskBox(:,:,i));
% inv_moments = Hu_Moments(eta);
% HuMoment = [HuMoment; inv_moments];
% end
% 
% HuMoment(isnan(HuMoment))=0;
% HuMomentFea = mean(HuMoment);
% 
% for j=1:1:length(HuMomentFea)
%     datanum=HuMomentFea(j);
%     featurename=['Hu_Moment_' int2str(j)];
%     featureList{length(featureList)+1} = featurename;
%     features=[features,datanum];
% end
% res = [res;features'];
% startPos = [startPos; length(res)+1];
% fprintf('Done extracting 7 Hu Moment features.\n');
% 
% [CentralMomentFea] = getMomentStatistics(cen_mmt,size(A,3));
% CentralMomentFea_names=fieldnames(CentralMomentFea);
% 
% for j=1:1:length(CentralMomentFea_names)
%     datanum=getfield(CentralMomentFea,CentralMomentFea_names{j});
%     featurename=['Central_Moment_' CentralMomentFea_names{j}];
%     featureList{length(featureList)+1} = featurename;
%     features=[features,datanum];
% end
% res = [res;features'];
% startPos = [startPos; length(res)+1];
% fprintf('Done extracting 20 Central Moment features.\n');


%% HOG feature extraction.
HOGfeatures=[];
tempHOG=[];
A = ROIonly;
A(isnan(A))=0;

tumorsize = size(A);


if length(size(ROIonly)) ==2
    tumorsize = [size(A),1];
    ResizedA=imresize(A,[60,60]);
    [tempHOG, vis8x8]=extractHOGFeatures(ResizedA,'CellSize',[8 8],'BlockSize',[4 4]); 
%tempLBP= feature_mat(find(maskBox(:,:,i)==1));%only extract tumor region
HOGfeaturesHIST = tempHOG;

else
% 3D rescale is applied across all cases to ensure consistent dimensions of extracted HOG
im = A;
ny=60;nx=60;nz= size(A,3); %% desired output rescaled dimensions


[y x z]=  ndgrid(linspace(1,size(im,1),ny),linspace(1,size(im,2),nx),linspace(1,size(im,3),nz));
ResizedA=interp3(im,x,y,z);

for k = 1 : size(A,3)
%'CellSize',[8 8],'BlockSize',[2 2] were default settings.
[tempHOG, vis8x8{k}]=extractHOGFeatures(ResizedA(:,:,k),'CellSize',[8 8],'BlockSize',[4 4]); 
%tempLBP= feature_mat(find(maskBox(:,:,i)==1));%only extract tumor region
HOGfeatures = [HOGfeatures; tempHOG];
end

HOGfeaturesHIST = mean(HOGfeatures);
end


for j=1:1:length(HOGfeaturesHIST)
    datanum=HOGfeaturesHIST(j);
    featurename=['Histogram_Of_Gradient_' int2str(j)];
    featureList{length(featureList)+1} = featurename;
    features=[features,datanum];
end
res = [res;features'];
startPos = [startPos; length(res)+1];
fprintf('Done extracting %d HOG features.\n',size(HOGfeaturesHIST,2));





%% LBP features n = 256, with a default lbp setting.
LBPfeatures=[];
tempLBP=[];
A = ROIonly;
A(isnan(A))=0;


if length(size(ROIonly)) ==2
    feature_mat=LBP_Extraction(A); % simple modification has been made to output a fea matrix.
    tempLBP= feature_mat(find(maskBox==1));%only extract tumor region
    LBPfeatures = [LBPfeatures; tempLBP];    
    LBPfeaturesHIST = hist(LBPfeatures,0:(256-1));
    LBPfeaturesHIST = LBPfeaturesHIST/sum(LBPfeaturesHIST);

else
    
    for p = 1 : size(A,3)
        feature_mat=LBP_Extraction(A(:,:,p)); % simple modification has been made to output a fea matrix.
        tempLBP= feature_mat(find(maskBox(:,:,p)==1));%only extract tumor region
        LBPfeatures = [LBPfeatures; tempLBP];
    end

    LBPfeaturesHIST = hist(LBPfeatures,0:(256-1));
    LBPfeaturesHIST = LBPfeaturesHIST/sum(LBPfeaturesHIST);
end

for j=1:1:length(LBPfeaturesHIST)
    datanum=LBPfeaturesHIST(j);
    featurename=['Local_Binary_Pattern_' int2str(j)];
    featureList{length(featureList)+1} = featurename;
    features=[features,datanum];
end
res = [res;features'];
startPos = [startPos; length(res)+1];
fprintf('Done extracting 256 LBP features.\n');





%% histogram features n 70 where we have 20 statiscs + 50 bins
Nbins=50;
[Global_hist] = getGlobalHistogram(ROIonly,Nbins);
Global_texture_names=fieldnames(Global_hist);

for j=1:1:length(Global_texture_names)
    datanum=getfield(Global_hist,Global_texture_names{j});
    featurename=['Global_' Global_texture_names{j}];
    featureList{length(featureList)+1} = featurename;
    features=[features,datanum];
end
res = [res;features'];
startPos = [startPos; length(res)+1];
fprintf('Done extracting 20 histogram features.\n');

[HistBinFeas] = getHistogramBin(ROIonly,Nbins);
for j=1:1:length(HistBinFeas)
    datanum=HistBinFeas(j);
    featurename=['Histogram_Bin_' int2str(j)];
    featureList{length(featureList)+1} = featurename;
    features=[features,datanum];
end
res = [res;features'];
startPos = [startPos; length(res)+1];
fprintf('Done extracting 50 histogram bin features.\n');


[ROIonly,levels] = prepareVolume(abs(ROIbox),maskBox,'Other',pixelW,pixelW,1,'pixelW','Matrix',algo_cell{1},Ng_mat); % Pre-processing, WBPF and resampling already applied. Thus, we insert 'Other', R=1, sliceS = pixelW / Scale='pixelW', respectively

%% initial here
%[ROIonly,maskBox,~,~ ] = getFixROI( ROIonly,0.03 );
do_texture=1;
if do_texture
[GLCM] = getGLCM(ROIonly,levels);
[GLCM_text] = getGLCMtextures(GLCM);
GLCM_text_names=fieldnames(GLCM_text);
for j=1:1:length(GLCM_text_names)
    datanum=getfield(GLCM_text,GLCM_text_names{j});
    featurename=['GLCM_' GLCM_text_names{j}];
    featureList{length(featureList)+1} = featurename;
    features=[features,datanum];
end
res = [res;features'];
startPos = [startPos; length(res)+1];
fprintf('Done extracting GLCM textures.\n');



[GLRLM] = getGLRLM(ROIonly,levels);
[GLRLM_text] = getGLRLMtextures(GLRLM);
GLRLM_text_names=fieldnames(GLRLM_text);
for j=1:1:length(GLRLM_text_names)
    datanum=getfield(GLRLM_text,GLRLM_text_names{j});
    featurename=['GLRLM_' GLRLM_text_names{j}];
    featureList{length(featureList)+1} = featurename;
    features=[features,datanum];
end
res = [res;features'];
startPos = [startPos; length(res)+1];
fprintf('Done extracting GLRLM textures.\n');


[GLSZM] = getGLSZM(ROIonly,levels);
[GLSZM_text] = getGLSZMtextures(GLSZM);
GLSZM_text_names=fieldnames(GLSZM_text);
for j=1:1:length(GLSZM_text_names)
    datanum=getfield(GLSZM_text,GLSZM_text_names{j});
    featurename=['GLSZM_' GLSZM_text_names{j}];
    featureList{length(featureList)+1} = featurename;
    features=[features,datanum];
end
res = [res;features'];
startPos = [startPos; length(res)+1];
fprintf('Done extracting GLSZM textures.\n');


[NGTDM,countValid] = getNGTDM(ROIonly,levels);
[NGTDM_text] = getNGTDMtextures(NGTDM,countValid);
NGTDM_text_names=fieldnames(NGTDM_text);
for j=1:1:length(NGTDM_text_names)
    datanum=getfield(NGTDM_text,NGTDM_text_names{j});
    featurename=['NGTDM_' NGTDM_text_names{j}];
    featureList{length(featureList)+1} = featurename;
    features=[features,datanum];
end
res = [res;features'];
startPos = [startPos; length(res)+1];
fprintf('Done extracting NGTDM textures.\n');

end

%%%%%%%%Gabor Bank%%%%%%
doGaborBank=1;

%%%%%%%%%Gabor image setting%%%%%%%%%%%%%%
filter_u=8;% 8 scales
filter_v=8; % 8 directions
filter_m=10; % length
filter_n=10;% width
gaborImg=getGaborFilterImg( ROIbox,filter_u,filter_v,filter_m,filter_n );

if doGaborBank

    
if length(size(ROIonly)) ==2   
    [GaborBank_text] = getGaborBank2(gaborImg,maskBox,algo_cell{1},Ng_mat);
else
    [GaborBank_text] = getGaborBank(gaborImg,maskBox,algo_cell{1},Ng_mat);
end

GaborBank_text_names=fieldnames(GaborBank_text);
for j=1:1:length(GaborBank_text_names)
    datanum=getfield(GaborBank_text,GaborBank_text_names{j});
    featurename=['GaborBank_' GaborBank_text_names{j}];
    featureList{length(featureList)+1} = featurename;
    features=[features,datanum];
end
res = [res;features'];
startPos = [startPos; length(res)+1];
fprintf('Done extracting GaborBank.\n');
end

featureList = featureList';

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% textures.(strExperiment).NonTextures = StatisticalFea;
% textures.(strExperiment).Global = Global_hist;
% textures.(strExperiment).GLCM = GLCM_text;
% textures.(strExperiment).GLRLM = GLRLM_text;
% textures.(strExperiment).GLSZM = GLSZM_text;
% textures.(strExperiment).NGTDM = NGTDM_text;
% textures.(strExperiment).GaborBank=GaborBank_text;
% textures.(strExperiment).parameters.R = R_mat;
% textures.(strExperiment).parameters.Scale = scale_cell;
% textures.(strExperiment).parameters.Algo = algo_cell;
% textures.(strExperiment).parameters.Ng = Ng_mat;

end

