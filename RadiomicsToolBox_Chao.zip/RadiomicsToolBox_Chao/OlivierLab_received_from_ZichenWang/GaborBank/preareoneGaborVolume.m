function [ ROIonly,levels,ROIbox,maskBox ] = preareoneGaborVolume( ROIbox,maskBox,textType,quantAlgo,Ng )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
if ~strcmp(textType,'Global') && ~strcmp(textType,'Matrix')
    error('Last argument must either be ''Global'' or ''Matrix''')
end

if strcmp(quantAlgo,'Lloyd')
    quantization = @(x,y) lloydQuantization(x,y);
elseif strcmp(quantAlgo,'Equal')
    quantization = @(x,y) equalQuantization(x,y);
elseif strcmp(quantAlgo,'Uniform')
    quantization = @(x,y) uniformQuantization(x,y);
else
    error('Error with quantization algorithm input. Must either be ''Equal'' or ''Lloyd'' or ''Uniform''')
end

ROIonly = ROIbox; ROIonly(~maskBox) = NaN; ROIonly(maskBox<0) = NaN;

% QUANTIZATION
if strcmp(textType,'Matrix')
    [ROIonly,levels] = quantization(ROIonly,Ng);
elseif strcmp(textType,'Global')
    levels = 0;
end
end

