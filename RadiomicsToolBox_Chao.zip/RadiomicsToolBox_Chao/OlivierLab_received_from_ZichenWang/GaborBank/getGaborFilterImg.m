function [ gaborImg ] = getGaborFilterImg( volume,filter_u,filter_v,filter_m,filter_n )

%
gaborArray = gaborFilterBank(filter_u,filter_v,filter_m,filter_n);
if size(volume,3)==1
    [u,v] = size(gaborArray);
    gaborResult = cell(u,v);
    for i = 1:u
        for j = 1:v
            gaborResult{i,j} = abs(imfilter(volume, gaborArray{i,j}));
        end
    end
    gaborImg=gaborResult;
    
elseif size(volume,3)>1
    tempvolume=zeros(size(volume));
    img_slice=size(volume,3);
    [u,v] = size(gaborArray);
    gaborResult=cell(u,v);
    for i=1:u
        for j=1:v
            for k=1:img_slice
                tempvolume(:,:,k)=abs(imfilter(volume(:,:,k), gaborArray{i,j}));
            end
            gaborResult{i,j}=tempvolume;
        end
    end
    gaborImg.Freimg=cell(1,u);
    gaborImg.Dirimg=cell(1,v);
    
    for i=1:u
       tempsum=zeros(size(volume));
       for j=1:v
           tempsum=tempsum+double(gaborResult{i,j});
       end
       gaborImg.Freimg{1,i}=tempsum;
    end
    
    for j=1:v
        temptotal=zeros(size(volume));
        for i=1:u
            temptotal=temptotal+double(gaborResult{i,j});
        end
        gaborImg.Dirimg{1,j}=temptotal;
    end  
end



end

