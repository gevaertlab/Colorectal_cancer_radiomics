function [wavelet] = computeWaveletRadiomics(volume,mask,scanType,pixelW,sliceS,R,scale)
% I is the original ROI, with voxels outside of ROI set to NaN.

% To prepare volume for first-order features extraction
% g stands for 'Global'
I = prepareVolume(volume,mask,scanType,pixelW,sliceS,R,scale,'Global');

    if sum(isnan(I(:)))
        I = fillBox(I); % Necessary in cases we have a ROI box containing NaN's.
    end
% I is preprocessed with isotropic resampling et al but not quantization. % not sure if this step could be prior to the next 
    
waveDec = wavedec3(I, 1, 'coif1');

% the order is stated in help-wavedec3.
% waveDec.dec{1}; %% LLL
% waveDec.dec{2}; %% HLL
% waveDec.dec{3}; %% LHL
% waveDec.dec{4}; %% HHL
% waveDec.dec{5}; %% LLH
% waveDec.dec{6}; %% HLH
% waveDec.dec{7}; %% LHH
% waveDec.dec{8}; %% HHH
waveletNames = {'LLL','HLL','LHL','HHL','LLH','HLH','LHH','HHH'};
firstOrderWavelet = struct;
GLCMnGLRLMWavelet = struct;
for i = 1:8
    waveletName = char(waveletNames(i));
    II = waveDec.dec{i};
    % firstOrder/intensity-based/global features.
    firstOrder = computeFirstOrderRadiomics(II);
    firstOrder = renameStructFields(firstOrder, waveletName, 'wavelet')
    firstOrderWavelet = catstruct(firstOrderWavelet, firstOrder);
    
    % quantization for matrix-based features extraction.
    Ng = 32;
    [II_m,levels] = uniformQuantization(II,Ng);
    % GLCM-based and GLRLM-based features
    GLCMnGLRLM = computeTextureRadiomics(II_m, levels);
    GLCMnGLRLM = renameStructFields(GLCMnGLRLM, waveletName, 'wavelet')
    GLCMnGLRLMWavelet = catstruct(GLCMnGLRLMWavelet, GLCMnGLRLM);
end
    wavelet = catstruct(firstOrderWavelet, GLCMnGLRLMWavelet);
end