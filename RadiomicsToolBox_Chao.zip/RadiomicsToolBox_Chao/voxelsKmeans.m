function [maskLow, maskHigh] = voxelsKmeans(ROI_ori)
[x,y,z] = find3d(~isnan(ROI_ori)); % find3d x,y,z coordinators, the function is adapted from
% 'computeBoundingBox.m' of 'mvallieres/radiomics'
ROI_real = ROI_ori(~isnan(ROI_ori)); % extract non-NaN elements of ROI_ori.
pixelList = [find(~isnan(ROI_ori)), x',y',z', ROI_real(:)];
pixel_idx = pixelList(~isnan(pixelList(:,5)),1);
pixelList_4Kmeans = pixelList(~isnan(pixelList(:,5)),2:5);

[cluster,C] = kmeans(pixelList_4Kmeans, 2); % returns an n-by-1 vector (idx) containing cluster indices of each observation

pixelListNew = [pixel_idx, pixelList_4Kmeans, cluster];

% create subvolume masks
% rename the clusters: high,short for 'high intensity subvolume', means higher average intensity across the
% cluster; low,short for 'low intensity subvolume', means lower average intensity across the
% cluster;
mask_raw=zeros(size(ROI_ori));
% uniformize cluster values: 1, 'low'; 2, 'high'.
if C(1,4) > C(2,4)
    pixelListNew(pixelListNew(:,6)==1,6)=3;
    pixelListNew(pixelListNew(:,6)==2,6)=1;
    pixelListNew(pixelListNew(:,6)==3,6)=2;
end
pixelListLow = pixelListNew(pixelListNew(:,6)==1,:); % low intensity cluster pixels.
pixelListHigh = pixelListNew(pixelListNew(:,6)==2,:); % high intensity cluster pixels.

pixel_idxLow = pixelListLow(:,1);
pixel_idxHigh = pixelListHigh(:,1);

maskLow = mask_raw;
maskLow(pixel_idxLow) = 1; % maskLow is the mask of low intensity subvolume

maskHigh = mask_raw;
maskHigh(pixel_idxHigh) = 1; % maskHigh is the mask of high intensity subvolume