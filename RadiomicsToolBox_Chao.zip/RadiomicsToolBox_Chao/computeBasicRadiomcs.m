function [basicRadiomics] = computeBasicRadiomcs(volume,mask,scanType,pixelW,sliceS,R,scale,quantAlgo,Ng)
% updated: Dec16, 2017.
% basicRadiomics: first order, shape and size features (three-dimensional features), texture features without any
% transform or filtering processes in the function.

% To prepare volume for first-order features extraction
% g stands for 'Global'
[ROIonly_g,levels_g,ROIbox_g,maskBox_g] = prepareVolume(volume,mask,scanType,pixelW,sliceS,R,scale,'Global'); % from 'mvallieres/radiomics' folder.

% To prepare volume for matrix-based features extraction.
% m stands for 'Matrix'
[ROIonly_m,levels_m,ROIbox_m,maskBox_m] = prepareVolume(volume,mask,scanType,pixelW,sliceS,R,scale,'Matrix',quantAlgo,Ng); % from 'mvallieres/radiomics' folder.

% subgroup1: first order features
[firstOrder] = computeFirstOrderRadiomics(ROIonly_g); % from "chihyanghsu0805/Radiomics"

% subgroup2: shape&size
if strcmp(scale,'pixelW')
    pixelResolution = pixelW;
else
    pixelResolution = pixelW/scale;
end
[shapeFeatures] = computeShapeFeatures(ROIonly_g, pixelResolution,pixelW,sliceS);

% subgroup3: matrix-based texture features % n approximate workaround for dealing with
% non-rectangular ROI's would be setting the pixels outside the ROI to 0 and using the funtion haralick from mahotas library.
% from "chihyanghsu0805/Radiomics", including quantization before computing GLCM
% matrix and GLRLM matrix. Not using methods from 'mvallieres/radiomics' to compute GLCM and GLRLM because they are different from Hugo Aerts' Nat Com description.
[GLCMnGLRLM] = computeTextureRadiomics(ROIonly_m, levels_m);

[GLSZM_matrix] = getGLSZM(ROIonly_m,levels_m); % 'mvallieres/radiomics'
[GLSZM_tmp] = getGLSZMtextures(GLSZM_matrix);
[GLSZM] = renameStructFields(GLSZM_tmp,'feature','GLSZM');

[NGTDM_matrix,countValid] = getNGTDM(ROIonly_m,levels_m); % 'mvallieres/radiomics'
[NGTDM_tmp] = getNGTDMtextures(NGTDM_matrix,countValid);
[NGTDM] = renameStructFields(NGTDM_tmp,'feature','NGTDM');
%% Gabor Bank
doGaborBank=1;
% M. Haghighat, S. Zonouz, M. Abdel-Mottaleb, "CloudID: Trustworthy 
% cloud-based and cross-enterprise biometric identification," 
% Expert Systems with Applications, vol. 42, no. 21, pp. 7905-7916, 2015. 
% University of Miami, haghighat@ieee.org
% GaborBank related functions will do the quantization by themselves.
%---Gabor image setting---
filter_u=8;% 8 scales
filter_v=8; % 8 directions
filter_m=10; % length
filter_n=10;% width
gaborImg=getGaborFilterImg(ROIbox_g,filter_u,filter_v,filter_m,filter_n );
if doGaborBank
    if length(size(ROIonly_g)) ==2
        [GaborBank_tmp] = getGaborBank2(gaborImg,maskBox_g,quantAlgo,Ng);
    else
        [GaborBank_tmp] = getGaborBank(gaborImg,maskBox_g,quantAlgo,Ng);
    end
end
[GaborBank] = renameStructFields(GaborBank_tmp,'Bank','Gabor');

% collect all features
basicRadiomics = catstruct(firstOrder, shapeFeatures, GLCMnGLRLM, GLSZM, NGTDM, GaborBank);
end