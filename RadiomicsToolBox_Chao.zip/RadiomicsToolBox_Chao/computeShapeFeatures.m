function [Radiomics] = computeShapeFeatures(ROIonly, pixelResolution,pixelW,sliceS)
% adapted from 'computeImageRadiomics.m' of 'chihyanghsu0805/Radiomics' and 'mvallieres/radiomics' folder.
% number of shape and size features (three-dimensional features): 9. updated Dec16, 2017

[x,y,z] = find3d(ROIonly); % find3d x,y,z coordinators, the function is adapted from
% 'computeBoundingBox.m' of <https://github.com/mvallieres/radiomics/>
pixelList = [x',y',z'];
shp = alphaShape(pixelList);
V = shp.volume; % different 'volume' definition from Aerts' 'Decoding...'.
A = shp.surfaceArea; % different 'surfaceArea' definition from Aerts' 'Decoding...'.

V = V*pixelResolution*pixelResolution*pixelResolution; 
% reference - 'getVolume.m' of <https://github.com/mvallieres/radiomics/>. 
% But, 'computeShapeRadiomics.m' in 'chihyanghsu0805/Radiomics' uses
% 'sliceT' instead of 'sliceS'.
A = A*(pixelResolution^2*pixelResolution^2*pixelResolution^2)^(1/3);

Radiomics.shapeSizeCompactness1 = V/sqrt(pi)/A^(2/3);
Radiomics.shapeSizeCompactness2 = 36*pi*V*V/A/A/A;
R = (V*3/4/pi)^(1/3);
Radiomics.shapeSizeSphericalDisproportion = A/4/pi/R/R;
Radiomics.shapeSizeSphericity = pi^(1/3)*(6*V)^(2/3)/A;
Radiomics.shapeSizeVolumeML = V*1e-3; %mL
Radiomics.shapeSizeSurfaceArea = A*1e-2; %cm^2
Radiomics.shapeSizeSurfaceVolumeRatio = A/V;

if length(size(ROIonly)) ==2
Radiomics.shapeSizeEccentricity = 0;
Radiomics.shapeSizeSolidity=1;
else
Radiomics.shapeSizeEccentricity = getEccentricity(ROIonly,pixelW,sliceS); 
Radiomics.shapeSizeSolidity = getSolidity(ROIonly,pixelW,sliceS);
% <https://github.com/mvallieres/radiomics/> still don't works.
end

% Radiomics.shapeSizemaxDiameter. Still lacking appropriate algorithm in Matlab. checked by Chao Huang on Dec 16, 2017.
% 'getSize.m' of <https://github.com/mvallieres/radiomics/> still don't works.

%% Centroid Information 
% Radiomics.shapeSizeCentroidX = Stats.Centroid(1);
% Radiomics.shapeSizeCentroidY = Stats.Centroid(2);
% Radiomics.shapeSizeCentroidZ = Stats.Centroid(3);
% Radiomics.shapeSizeClassification = Stats.Classification;

%% Major Axis and MAximum Diameter Information
% nVoxels = size(Stats.PixelList,1);
% Radiomics.shapeSizeMaximumDiameter = 0;
% Radiomics.shapeSizeMajorAxisX = 0;
% Radiomics.shapeSizeMajorAxisY = 0;
% Radiomics.shapeSizeMajorAxisZ = 0;
% for i = 1:nVoxels
%     D = 2*norm(Stats.Centroid-Stats.PixelList(i));
%     if D > Radiomics.shapeSizeMaximumDiameter
%         Radiomics.shapeSizeMaximumDiameter = D; %%Check
%         Radiomics.shapeSizeMajorAxisX = Stats.PixelList(i,1)-Radiomics.shapeSizeCentroidX;
%         Radiomics.shapeSizeMajorAxisY = Stats.PixelList(i,2)-Radiomics.shapeSizeCentroidY;
%         Radiomics.shapeSizeMajorAxisZ = Stats.PixelList(i,3)-Radiomics.shapeSizeCentroidZ;
%     end
% end
% Radiomics.shapeSizeMaximumDiameter = Radiomics.shapeSizeMaximumDiameter*sqrt(Stats.VoxelResolution(1)^2+Stats.VoxelResolution(2)^2+Stats.VoxelResolution(3)^2);