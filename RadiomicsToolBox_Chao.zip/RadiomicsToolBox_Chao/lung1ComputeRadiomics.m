function [Radiomics, RadiomicsLow, RadiomicsHigh] = lung1ComputeRadiomics(volume,mask,scanType,pixelW,sliceS,R,scale,ROI_ori)

% INPUTS:
% - dicomPath: the toppest file path consisting all the DICOM and RT structure sets of a patient.

% - R: Numerical value specifying the ratio of weight to band-pass coefficients 
%      over the weigth of the rest of coefficients (HHH and LLL). Provide R=1 
%      to not perform wavelet band-pass filtering.    
% - scale: Numerical value specifying the scale at which 'volume' is isotropically 
%          resampled (mm). If a string 'pixelW' is entered as input, the
%          volume will be isotropically resampled at the initial in-plane
%          resolution of 'volume' specified by 'pixelW'.
% -------------------------------------------------------------------------
% OUTPUTS:
% - Radiomics


% Features for whole volume.

% Group1: basicRadiomics
% includes first order, shape&size, texture features without any
% transform or filtering processes in the function.
[basicRadiomics] = computeBasicRadiomcs(volume,mask,scanType,pixelW,sliceS,R,scale);

% Group2: wavelet
[wavelet] = computeWaveletRadiomics(volume,mask,scanType,pixelW,sliceS,R,scale);

% Group3: Coliage----- Co-occurrence of local anisotropic gradient orientations (CoLIAGe)
[Coliage1, Coliage2] = computeColiageRadiomics(volume,mask,scanType,pixelW,sliceS,R,scale);

Radiomics = catstruct(basicRadiomics, wavelet, Coliage1, Coliage2);



% Features for subvolumes.
% K-means to split into two subvolumes.
[maskLow, maskHigh] = voxelsKmeans(ROI_ori);

% 1. Features for low intensity subvolume.
% Group1: basicRadiomics
% includes first order, shape&size, texture features without any
% transform or filtering processes in the function.
[basicRadiomicsLow] = computeBasicRadiomcs(volume,maskLow,scanType,pixelW,sliceS,R,scale);

% Group2: wavelet
[waveletLow] = computeWaveletRadiomics(volume,maskLow,scanType,pixelW,sliceS,R,scale);

% Group3: Coliage----- Co-occurrence of local anisotropic gradient orientations (CoLIAGe)
[Coliage1Low, Coliage2Low] = computeColiageRadiomics(volume,maskLow,scanType,pixelW,sliceS,R,scale);

RadiomicsLow = catstruct(basicRadiomicsLow, waveletLow, Coliage1Low, Coliage2Low);

% 2. Features for high intensity subvolume.
% Group1: basicRadiomics
% includes first order, shape&size, texture features without any
% transform or filtering processes in the function.
[basicRadiomicsHigh] = computeBasicRadiomcs(volume,maskHigh,scanType,pixelW,sliceS,R,scale);

% Group2: wavelet
[waveletHigh] = computeWaveletRadiomics(volume,maskHigh,scanType,pixelW,sliceS,R,scale);

% Group3: Coliage----- Co-occurrence of local anisotropic gradient orientations (CoLIAGe)
[Coliage1High, Coliage2High] = computeColiageRadiomics(volume,maskHigh,scanType,pixelW,sliceS,R,scale);

RadiomicsHigh = catstruct(basicRadiomicsHigh, waveletHigh, Coliage1High, Coliage2High);