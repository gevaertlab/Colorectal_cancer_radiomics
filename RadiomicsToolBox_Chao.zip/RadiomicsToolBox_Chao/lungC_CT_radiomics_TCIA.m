% for Chao's Mac OS.
  cd '/Users/messi/Documents/private_research/Stanford_BMI/TCIA_LUNG1_RadiomicsToolBox_Chao'
  load('/Users/messi/Documents/private_research/Stanford_BMI/radiomicsFieldNames.mat')
% for Joe's Windows OS.
 %cd 'E:\chao20170716\TCIA_LUNG1_RadiomicsToolBox_Chao'
 %load('E:\chao20170716\radiomicsFieldNames.mat')

RadiomicsTable = cell2table(cell(0,556), 'VariableNames', radiomicsFieldNames);
RadiomicsLowTable = cell2table(cell(0,556), 'VariableNames', radiomicsFieldNames);
RadiomicsHighTable = cell2table(cell(0,556), 'VariableNames', radiomicsFieldNames);
fidBasic = fopen('errorsIterationBasic.err','wt');
errorIterationRecoderBasic = [];
fidLow = fopen('errorsIterationLow.err','wt');
fidHigh = fopen('errorsIterationHigh.err','wt');
errorIterationRecoderLow = [];
errorIterationRecoderHigh = [];
for i = 1:422
% for Chao's Mac OS.
    dicomPath = strcat('/Users/messi/Documents/private_research/Stanford_BMI/TCIA_TCGA/Lung1_dataset/DOI/LUNG1-', num2str(i,'%03d'));
% for Joe's Windows OS.
   % dicomPath = strcat('E:\chao20170716\TCIA_TCGA\Lung1_dataset\DOI\LUNG1-', num2str(i,'%03d'));

S = subdir(dicomPath); % from 'mvallieres-chao_revised' folder.if isempty(sData{4})
if sum([S(~ismember({S.name},{'.','..'})).isdir]) < 3  
    continue
else
    try
    [sData] = readDICOMdir(dicomPath,1); % from 'mvallieres-chao_revised' folder.
    
    volume = sData{2}.scan.volume;
    mask = sData{2}.scan.contour.mask;
    volume_temp = volume + 32770; % avoid the Os being deleted after multiply mask.
    ROI_ori=volume_temp.*mask;
    ROI_ori(ROI_ori == 0) = NaN;
    ROI_ori = ROI_ori-32770; % original ROI before resampling.
    
    boxBound = sData{2}.scan.contour.boxBound;
    boxMask = sData{2}.scan.contour.boxMask;
    boxROI = volume(boxBound(1,1):boxBound(1,2),boxBound(2,1):boxBound(2,2),boxBound(3,1):boxBound(3,2));
    scanType = sData{2}.type;
    pixelW = sData{2}.scan.pixelW;
    sliceS = sData{2}.scan.sliceS;
    R = 1; % no wavelet band-pass filtering with R = 1.
    scale = 1; % Isotropic resampling. To get a 3-D
    % isotropic volume, scale is the new resolution(Isotropic voxel size).
    % e.g. scale = 1, is isotropically resampled to a voxel size of 1x1x1
    % mm3.
    
    [ID]=struct('PatientID',strcat('LUNG1-',num2str(i,'%03d')));

    % ******************Features for whole volume******************
    % Group1: basicRadiomics
    % includes first order, shape&size, texture features without any
    % transform or filtering processes in the function.
    [basicRadiomics] = computeBasicRadiomcs(volume,mask,scanType,pixelW,sliceS,R,scale);
    % Group2: wavelet ('fillbox.m' is used for ROI with NaNs??, not sure if correct)
    % revised by Chao Huang from 'chihyanghsu0805'
    [wavelet] = computeWaveletRadiomics(volume,mask,scanType,pixelW,sliceS,R,scale);
    % Group3: Coliage----- Co-occurrence of local anisotropic gradient orientations (CoLIAGe)
    [Coliage1, Coliage2] = computeColiageRadiomics(volume,mask,scanType,pixelW,sliceS,R,scale);
    Radiomics = catstruct(basicRadiomics, wavelet, Coliage1, Coliage2);
    Radiomics = catstruct(ID, Radiomics);
    
    RadiomicsTable_temp = struct2table(Radiomics);
    RadiomicsTable = [RadiomicsTable;RadiomicsTable_temp];
    catch MEbasic
        errorIterationRecoderBasic = [errorIterationRecoderBasic;i];
        fprintf(fidBasic,'\n********************\n****Iteration %d*****\n********************\nMessage:"%s".\t\n',i, getReport(MEbasic));
        continue;
    end
    
    % Features for subvolumes.
    % K-means to split into two subvolumes.
    [maskLow, maskHigh] = voxelsKmeans(ROI_ori);
    
    try    
        % **************1. Features for low intensity subvolume.*********    
        % Group1: basicRadiomics    
        % includes first order, shape&size, texture features without any    
        % transform or filtering processes in the function.    
        [basicRadiomicsLow] = computeBasicRadiomcs(volume,maskLow,scanType,pixelW,sliceS,R,scale);
    
        % Group2: wavelet    
        [waveletLow] = computeWaveletRadiomics(volume,maskLow,scanType,pixelW,sliceS,R,scale);
    
        % Group3: Coliage----- Co-occurrence of local anisotropic gradient orientations (CoLIAGe)   
        [Coliage1Low, Coliage2Low] = computeColiageRadiomics(volume,maskLow,scanType,pixelW,sliceS,R,scale);    
        RadiomicsLow = catstruct(basicRadiomicsLow, waveletLow, Coliage1Low, Coliage2Low);        
        RadiomicsLow = catstruct(ID, RadiomicsLow);    
    
        RadiomicsLowTable_temp = struct2table(RadiomicsLow);    
        RadiomicsLowTable = [RadiomicsLowTable;RadiomicsLowTable_temp];
    catch MElow
        errorIterationRecoderLow = [errorIterationRecoderLow;i];
        fprintf(fidLow,'\n********************\n****Iteration %d*****\n********************\nMessage:"%s".\t\n',i, getReport(MElow));
    end
    
    
    try
        % ************2. Features for high intensity subvolume.************
        % Group1: basicRadiomics
        % includes first order, shape&size, texture features without any
        % transform or filtering processes in the function.
        [basicRadiomicsHigh] = computeBasicRadiomcs(volume,maskHigh,scanType,pixelW,sliceS,R,scale);
        % Group2: wavelet
        [waveletHigh] = computeWaveletRadiomics(volume,maskHigh,scanType,pixelW,sliceS,R,scale);
        % Group3: Coliage----- Co-occurrence of local anisotropic gradient orientations (CoLIAGe)
        [Coliage1High, Coliage2High] = computeColiageRadiomics(volume,maskHigh,scanType,pixelW,sliceS,R,scale);
        RadiomicsHigh = catstruct(basicRadiomicsHigh, waveletHigh, Coliage1High, Coliage2High);    
        RadiomicsHigh = catstruct(ID, RadiomicsHigh);
    
        RadiomicsHighTable_temp = struct2table(RadiomicsHigh);    
        RadiomicsHighTable = [RadiomicsHighTable;RadiomicsHighTable_temp];
    catch MEhigh
        errorIterationRecoderHigh = [errorIterationRecoderHigh;i];
        fprintf(fidHigh,'\n********************\n****Iteration %d*****\n********************\nMessage:"%s".\t\n',i, getReport(MEhigh));
    end

end

end
fclose(fidBasic);
fclose(fidLow);
fclose(fidHigh);

% for Chao's Mac OS.
  cd '/Users/messi/Documents/private_research/Stanford_BMI/TCIA_analysis/dataArchive'
% for Joe's Windows OS.
 %cd 'E:\chao20170716\TCIA_analysis\dataArchive'

% write table to csv
writetable(RadiomicsGtvTable, 'RadiomicsGtvTable.csv');
writetable(RadiomicsLowTable, 'RadiomicsLowTable.csv');
writetable(RadiomicsHighTable, 'RadiomicsHighTable.csv');

% write matrix to csv
csvwrite('errorIterationRecoderBasic.csv', errorIterationRecoderBasic);
csvwrite('errorIterationRecoderLow.csv', errorIterationRecoderLow);
csvwrite('errorIterationRecoderHigh.csv', errorIterationRecoderHigh);

% get common observations shared across gtv and subvolumes.
low = readtable('RadiomicsLowTable.csv');
high = readtable('RadiomicsHighTable.csv');
gtv = readtable('RadiomicsGtvTable.csv');

%intersected = intersect(low(:,1),high(:,1));
%lowIntersected = join(intersected,low);
%highIntersected = join(intersected,high);
%gtvIntersected = join(intersected, gtv);

%writetable(lowIntersected, 'lowIntersected.csv');
%writetable(highIntersected, 'highIntersected.csv');
%writetable(gtvIntersected, 'gtvIntersected.csv');

% Chao's Mac
clinicData = readtable('/Users/messi/Documents/private_research/Stanford_BMI/TCIA_TCGA/Lung1_dataset/Lung1.clinical.csv');
% Joy's Windows
%clinicData = readtable('E:\chao20170716\TCIA_TCGA\Lung1_dataset\Lung1.clinical.csv');
clinicData = clinicData(:, [1 3:7 9:end 8 2]); % reorder Cols.

%lowClinic = innerjoin(lowIntersected, clinicData,'keys', 'PatientID');
%highClinic = innerjoin(highIntersected, clinicData,'keys', 'PatientID');
%gtvClinic = innerjoin(gtvIntersected, clinicData,'keys', 'PatientID');

lowClinic = innerjoin(clinicData, low, 'keys', 'PatientID'); 
highClinic = innerjoin(clinicData, high, 'keys', 'PatientID');
gtvClinic = innerjoin(clinicData, gtv, 'keys', 'PatientID');

writetable(lowClinic, 'lowClinic.csv');
writetable(highClinic, 'highClinic.csv');
writetable(gtvClinic, 'gtvClinic.csv');