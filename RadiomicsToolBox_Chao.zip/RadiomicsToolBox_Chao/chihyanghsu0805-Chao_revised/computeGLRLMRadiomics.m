function Radiomics = computeGLRLMRadiomics(glrlm)
nMatrices = size(glrlm, 3);
nLength = size(glrlm, 2);
nLevels = size(glrlm, 1);
Radiomics.GLRLMShortRunEmphasis = 0;
Radiomics.GLRLMLongRunEmphasis = 0;
Radiomics.GLRLMGrayLevelNonUniformity = 0;
Radiomics.GLRLMRunLengthNonUniformity = 0;
Radiomics.GLRLMRunPercentage = 0;
Radiomics.GLRLMLowGrayLevelRunEmphasis = 0;
Radiomics.GLRLMHighGrayLevelRunEmphasis = 0;
Radiomics.GLRLMShortRunLowGrayLevelEmphasis = 0;
Radiomics.GLRLMShortRunHighGrayLevelEmphasis = 0;
Radiomics.GLRLMLongRunLowGrayLevelEmphasis = 0;
Radiomics.GLRLMLongRunHighGrayLevelEmphasis = 0;
j = (1:nLength)'.^2;
i = (1:nLevels)'.^2;
for k = 1:nMatrices
    p = glrlm(:,:,k);
    Radiomics.GLRLMShortRunEmphasis = sum(p*(1./j))/nMatrices+Radiomics.GLRLMShortRunEmphasis;
    Radiomics.GLRLMLongRunEmphasis = sum(p*(j))/nMatrices+Radiomics.GLRLMLongRunEmphasis;
    Radiomics.GLRLMGrayLevelNonUniformity = sum(sum(p,2).^2)/nMatrices+Radiomics.GLRLMGrayLevelNonUniformity;
    Radiomics.GLRLMRunLengthNonUniformity = sum(sum(p,1).^2)/nMatrices+Radiomics.GLRLMRunLengthNonUniformity;
    Radiomics.GLRLMRunPercentage = sum(sum(p))/numel(p)/nMatrices+Radiomics.GLRLMRunPercentage;
    Radiomics.GLRLMLowGrayLevelRunEmphasis = sum((1./i)'*p)/nMatrices+Radiomics.GLRLMLowGrayLevelRunEmphasis;
    Radiomics.GLRLMHighGrayLevelRunEmphasis = sum(i'*p)/nMatrices+Radiomics.GLRLMHighGrayLevelRunEmphasis;
    Radiomics.GLRLMShortRunLowGrayLevelEmphasis = (1./i)'*(p*(1./j))/nMatrices+Radiomics.GLRLMShortRunLowGrayLevelEmphasis;
    Radiomics.GLRLMShortRunHighGrayLevelEmphasis = (i)'*(p*(1./j))/nMatrices+Radiomics.GLRLMShortRunHighGrayLevelEmphasis;
    Radiomics.GLRLMLongRunLowGrayLevelEmphasis = (1./i)'*(p*j)/nMatrices+Radiomics.GLRLMLongRunLowGrayLevelEmphasis;
    Radiomics.GLRLMLongRunHighGrayLevelEmphasis = i'*(p*(j))/nMatrices+Radiomics.GLRLMLongRunHighGrayLevelEmphasis;
end