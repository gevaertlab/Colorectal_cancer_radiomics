function [Radiomics] = computeFirstOrderRadiomics(I)
% I is ROIonly for global features(first order, shape & size, textures)
% adapted from 'computeImageRadiomics.m' of 'chihyanghsu0805/Radiomics'
% number of features computed: 23. updated Dec16, 2017

m = floor(min(min(min(I))));
M = ceil(max(max(max(I))));
levels = m:M;

X = I(~isnan(I)); % added by Chao Huang.
N = numel(I);
% X = reshape(I, [N 1]); % deleted cuz useless with "I = I(~isnan(I))", proposed by Chao Huang.
X_Bar = sum(X)/N;
if max(levels) == 0 && min(levels) == 0
    [P, ~] = histcounts(X);
else
    [P, ~] = histcounts(X, levels);
end
P = P/N;
Radiomics.firstOrderEnergy = sum(P.^2);


% Entropy is a statistical measure of randomness that can be used to characterize
% the texture of the input image
Radiomics.firstOrderEntropy = -P(P~=0)*log2(P(P~=0)');


% Kurtosis is a measure of how outlier-prone a distribution is. The kurtosis
% of the normal distribution is 3. Distributions that are more outlier-prone
% than the normal distribution have kurtosis greater than 3; distributions
% that are less outlier-prone have kurtosis less than 3.
Radiomics.firstOrderKurtosis = kurtosis(X, 1);

Radiomics.firstOrderSum = sum(X);
Radiomics.firstOrderMaximum = max(X);
Radiomics.firstOrderMean = X_Bar;


%   Mean deviation (also called mean absolute deviation)
Radiomics.firstOrderMeanAbsoluteDeviation = mad(X);

Radiomics.firstOrderMedian = median(X);
Radiomics.firstOrderMinimum = min(X);
Radiomics.firstOrderRange = range(X);


%   Root mean square (RMS)
Radiomics.firstOrderRootMeanSquare = rms(X);

% Skewness is a measure of the asymmetry of the data around the sample mean.
% If skewness is negative, the data are spread out more to the left of the mean
% than to the right. If skewness is positive, the data are spread out more to the
% right. The skewness of the normal distribution (or any perfectly symmetric
% distribution) is zero.
Radiomics.firstOrderSkewness = skewness(X, 1);

Radiomics.firstOrderStd = std(X);
Radiomics.firstOrderUniformity = P*P';
Radiomics.firstOrderVariance = var(X);

% features above are from "Chihyanghsu0805/Radiomics".

% features below are from "adityaapte/CERR".

% Median absolute deviation
Radiomics.firstOrderMedianAbsDev = sum(abs(X-Radiomics.firstOrderMedian))/numel(X);

%   P10
p10 = prctile(X,10);
Radiomics.firstOrderP10 = p10;

%   P90
p90 = prctile(X,90);
Radiomics.firstOrderP90 = p90;

X10_90 = X(X >= p10 & X <= p90);

%   Robust Mean Absolute Deviation
Radiomics.firstOrderRobustMeanAbsDev  = mad(X10_90);

%   Robust Median Absolute Deviation
Radiomics.firstOrderRobustMedianAbsDev  = sum(abs(X10_90-median(X10_90)))...
    / numel(X10_90);

% Inter-Quartile Range (IQR)
% P75 - P25
p75 = prctile(X,75);
p25 = prctile(X,25);
Radiomics.firstOrderInterQuartileRange = p75 - p25;

% Quartile coefficient of Dispersion
Radiomics.firstOrderCoeffDispersion = (p75-p25)/(p75+p25);

% Coefficient of variation
Radiomics.firstOrderCoeffVariation = Radiomics.firstOrderStd / Radiomics.firstOrderMean;
