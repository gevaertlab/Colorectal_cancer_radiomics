function [GLCMnGLRLM] = computeTextureRadiomics(II, levels)
% levels, is replaced by Chao Huang according to 'prepareVolume.m' of 'mvallieres/radiomics'

 % m = floor(min(min(min(II))));
 % M = ceil(max(max(max(II))));
 % GLCM = computeGrayLevelCoCurrenceMatrix(II, m:M);
 GLCM = computeGrayLevelCoCurrenceMatrix(II, levels);
 GLCMRadiomics = computeGLCMRadiomics(GLCM);
 % GLRLM = computeGrayLevelRunLengthMatrix(II, m:M);
 GLRLM = computeGrayLevelRunLengthMatrix(II, levels);
 GLRLMRadiomics = computeGLRLMRadiomics(GLRLM);
 GLCMnGLRLM = catstruct(GLCMRadiomics,GLRLMRadiomics);
